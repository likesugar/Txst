package com.jiuguan.tavern.ui

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.util.Base64
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.KeyEvent
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.jiuguan.tavern.R
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * WebView 壳（v1.5 复刻）：
 * 加载 http://127.0.0.1:{port}/；返回键=网页后退；主框架连接失败弹回端口设置页；
 * onShowFileChooser 支持网页文件选择（Android 10+ 免存储权限）。
 */
class WebActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private var port = SetupActivity.DEFAULT_PORT
    private var retrying = false      // 主框架错误只处理一次，防重复跳转

    private var fileCallback: ValueCallback<Array<Uri>>? = null

    private val filePicker =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            if (r.resultCode == Activity.RESULT_OK && r.data != null) {
                fileCallback?.onReceiveValue(
                    WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data)
                )
            } else {
                fileCallback?.onReceiveValue(null)
            }
            fileCallback = null
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_web)

        port = intent.getIntExtra(SetupActivity.KEY_PORT, SetupActivity.DEFAULT_PORT)
        web = findViewById(R.id.web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            cacheMode = WebSettings.LOAD_DEFAULT   // 缓存加速二次加载
            useWideViewPort = true
            loadWithOverviewMode = true
        }
        web.setBackgroundColor(0xFF000000.toInt())

        // 7 天未使用：清空 WebView 缓存/Cookie/DOM 存储（端口等设置保留）
        housekeeping()

        // 图片保存：长按图片弹出保存；下载链接直接入相册
        web.setOnLongClickListener {
            val hit = web.hitTestResult
            val src = hit.extra
            if ((hit.type == WebView.HitTestResult.IMAGE_TYPE ||
                hit.type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) &&
                !src.isNullOrBlank()
            ) {
                MaterialAlertDialogBuilder(this)
                    .setTitle("保存图片")
                    .setMessage(src)
                    .setPositiveButton("保存") { _, _ -> saveImageAsync(src) }
                    .setNegativeButton("取消", null)
                    .show()
                true
            } else false
        }
        web.setDownloadListener { url, _, _, _, _ -> saveImageAsync(url) }

        // 全屏沉浸：隐藏状态栏+导航栏，下滑临时唤出；焦点变化后自动恢复
        WindowCompat.setDecorFitsSystemWindows(window, false)
        hideSystemBars()

        web.webViewClient = object : WebViewClient() {

            /** 图片资源代理：命中缓存直接回放（离线可用），未命中联网拉取并存盘。
             *  只代理图片扩展名；CSS/JS/字体一律直连（v2.7 全量代理会把样式搞挂）。 */
            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? {
                val url = request.url.toString()
                if (request.method != "GET") return null
                val host = request.url.host ?: return null
                if (host == "127.0.0.1" || host == "localhost") return null
                if (!url.startsWith("http://") && !url.startsWith("https://")) return null
                if (!isImageUrl(url)) return null

                ImageCache.get(this@WebActivity, url)?.let { f ->
                    return WebResourceResponse(guessMime(f.name), null, FileInputStream(f))
                }
                
                return try {
                    val conn = URL(url).openConnection() as HttpURLConnection
                    conn.connectTimeout = 10000
                    conn.readTimeout = 20000
                    conn.instanceFollowRedirects = true
                    // 透传 WebView 原始请求头（UA/Cookie/Referer 等），避免被 CDN 拒
                    request.requestHeaders.forEach { (k, v) ->
                        if (!k.equals("host", true)) conn.setRequestProperty(k, v)
                    }
                    if (conn.responseCode !in 200..299) {
                        conn.disconnect(); return null
                    }
                    val len = conn.contentLengthLong
                    if (len > 20L * 1024 * 1024) {   // 超大文件不进缓存，交还 WebView 流式处理
                        conn.disconnect(); return null
                    }
                    val mime = (conn.contentType ?: guessMime(url)).substringBefore(";").trim()
                    val bytes = conn.inputStream.use { it.readBytes() }
                    ImageCache.put(this@WebActivity, url, bytes)
                    WebResourceResponse(mime.ifEmpty { "image/jpeg" }, null, ByteArrayInputStream(bytes))
                } catch (e: Exception) {
                    null   // 失败交还 WebView 原生加载
                }
            }

            override fun onReceivedError(
                view: WebView, request: WebResourceRequest, error: WebResourceError
            ) {
                // 连不上：不弹提示，回到端口设置页（预填端口，可改可重试）
                if (request.isForMainFrame && !retrying) {
                    retrying = true
                    startActivity(
                        Intent(this@WebActivity, SetupActivity::class.java)
                            .putExtra(SetupActivity.EXTRA_RETRY, true)
                            .putExtra(SetupActivity.EXTRA_FAILED_URL, "http://127.0.0.1:$port/")
                    )
                    finish()
                }
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView, callback: ValueCallback<Array<Uri>>, params: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)   // 防回调叠加
                fileCallback = callback
                val intent = params.createIntent().apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                return try {
                    filePicker.launch(intent); true
                } catch (e: Exception) {
                    fileCallback = null; false
                }
            }
        }

        web.loadUrl("http://127.0.0.1:$port/")
    }

    private fun isImageUrl(url: String): Boolean {
        val path = url.substringBefore('?').substringBefore('#').lowercase()
        return path.endsWith(".png") || path.endsWith(".jpg") || path.endsWith(".jpeg") ||
            path.endsWith(".webp") || path.endsWith(".gif") || path.endsWith(".avif") ||
            path.endsWith(".bmp") || path.endsWith(".svg") || path.endsWith(".ico")
    }

    private fun guessMime(nameOrUrl: String): String = when {
        nameOrUrl.contains(".png", true) -> "image/png"
        nameOrUrl.contains(".webp", true) -> "image/webp"
        nameOrUrl.contains(".gif", true) -> "image/gif"
        nameOrUrl.contains(".svg", true) -> "image/svg+xml"
        nameOrUrl.contains(".avif", true) -> "image/avif"
        nameOrUrl.contains(".bmp", true) -> "image/bmp"
        nameOrUrl.contains(".ico", true) -> "image/x-icon"
        nameOrUrl.contains(".css", true) -> "text/css"
        nameOrUrl.contains(".js", true) -> "application/javascript"
        else -> "image/jpeg"
    }

    /** 7 天未使用 → 清 WebView 缓存/Cookie/DOM 数据 */
    private fun housekeeping() {
        val sp = getSharedPreferences("app", MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val last = sp.getLong("last_used", 0)
        if (last > 0 && now - last > 7L * 24 * 3600 * 1000) {
            web.clearCache(true)
            CookieManager.getInstance().apply {
                removeAllCookies(null); flush()
            }
            WebStorage.getInstance().deleteAllData()
            Toast.makeText(this, "已清理 7 天未使用的浏览数据", Toast.LENGTH_SHORT).show()
        }
        sp.edit().putLong("last_used", now).apply()
    }

    /** 图片保存到相册「Pictures/本地酒馆」（MediaStore，Android 10+ 免权限） */
    private fun saveImageAsync(src: String) {
        Thread {
            var okMsg: String? = null
            var errMsg: String? = null
            try {
                val cached = ImageCache.get(applicationContext, src)   // 页面显示过 → 缓存必有，离线也能存
                val bytes: ByteArray = cached?.readBytes() ?: when {
                    src.startsWith("data:") -> {
                        val b64 = src.substringAfter("base64,", "")
                        if (b64.isEmpty()) throw IllegalArgumentException("不支持的 data 格式")
                        Base64.decode(b64, Base64.DEFAULT)
                    }
                    else -> {
                        val abs = if (src.startsWith("http")) src
                                  else "http://127.0.0.1:$port${if (src.startsWith("/")) "" else "/"}$src"
                        val conn = URL(abs).openConnection() as HttpURLConnection
                        conn.connectTimeout = 15000
                        conn.readTimeout = 30000
                        conn.instanceFollowRedirects = true
                        conn.setRequestProperty("User-Agent", web.settings.userAgentString)
                        try { conn.inputStream.use { it.readBytes() } } finally { conn.disconnect() }
                    }
                }
                val ext = when {
                    src.contains(".jpg") || src.contains(".jpeg") -> "jpg"
                    src.contains(".webp") -> "webp"
                    src.contains(".gif") -> "gif"
                    else -> "png"
                }
                val mime = "image/$ext"
                val cv = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, "tavern_${System.currentTimeMillis()}.$ext")
                    put(MediaStore.Images.Media.MIME_TYPE, mime)
                    if (Build.VERSION.SDK_INT >= 29)
                        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/本地酒馆")
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                    ?: throw IllegalStateException("相册写入被拒绝")
                contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
                okMsg = "已保存到 相册/Pictures/本地酒馆"
            } catch (e: Exception) {
                errMsg = "保存失败：${e.message ?: "未知错误"}"
            }
            runOnUiThread {
                Toast.makeText(this, okMsg ?: errMsg, Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && ::web.isInitialized) hideSystemBars()
    }

    private fun hideSystemBars() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    @Deprecated("Deprecated in Java")
    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack()
        else super.onBackPressed()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        // 兼容部分 ROM 的物理返回键路径
        if (keyCode == KeyEvent.KEYCODE_BACK && web.canGoBack()) {
            web.goBack(); return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onDestroy() {
        web.apply {
            loadUrl("about:blank")
            (parent as? android.view.ViewGroup)?.removeAllViews()
            destroy()
        }
        super.onDestroy()
    }
}
