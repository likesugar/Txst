package com.jiuguan.tavern.ui

import android.content.Context
import java.io.File
import java.security.MessageDigest

/**
 * 外链资源持久缓存：在线时经 shouldInterceptRequest 代理存盘，离线时直接回放。
 * 存 filesDir（不受系统缓存清理影响、不纳入 7 天清理）；总量超限按最旧淘汰。
 */
object ImageCache {

    private const val MAX_BYTES = 200L * 1024 * 1024   // 200MB 上限
    private const val TRIM_TO = 150L * 1024 * 1024     // 淘汰到 150MB

    fun dir(context: Context): File =
        File(context.filesDir, "res_cache").apply { mkdirs() }

    fun key(url: String): String =
        MessageDigest.getInstance("MD5").digest(url.toByteArray())
            .joinToString("") { "%02x".format(it) }

    fun get(context: Context, url: String): File? {
        val f = File(dir(context), key(url))
        return if (f.isFile && f.length() > 0) f else null
    }

    fun put(context: Context, url: String, bytes: ByteArray) {
        try {
            val d = dir(context)
            val tmp = File(d, "tmp_${Thread.currentThread().id}")
            tmp.writeBytes(bytes)
            tmp.renameTo(File(d, key(url)))
            trimAsync(d)
        } catch (e: Exception) {
            // 缓存失败不影响页面
        }
    }

    private fun trimAsync(d: File) {
        Thread {
            try {
                var files = d.listFiles()?.filter { it.isFile && !it.name.startsWith("tmp_") } ?: return@Thread
                var total = files.sumOf { it.length() }
                if (total <= MAX_BYTES) return@Thread
                files = files.sortedBy { it.lastModified() }
                for (f in files) {
                    if (total <= TRIM_TO) break
                    val len = f.length()
                    if (f.delete()) total -= len
                }
            } catch (e: Exception) {
            }
        }.start()
    }
}
