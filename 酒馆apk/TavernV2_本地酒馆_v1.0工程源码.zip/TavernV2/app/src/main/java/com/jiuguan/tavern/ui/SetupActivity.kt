package com.jiuguan.tavern.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.jiuguan.tavern.R

/**
 * 端口设置页（v1.5 复刻）：
 * - 已存端口 + 正常启动 → 直接进酒馆，不停留
 * - 连接失败返回 → 提示具体地址 + 预填端口，改完一键重试
 * - 浮动提示只放 TextInputLayout 一处（修复 hint 重叠）
 */
class SetupActivity : AppCompatActivity() {

    companion object {
        const val KEY_PORT = "server_port"     // 与 v1.x 同 key，老用户数据无缝
        const val DEFAULT_PORT = 8000
        const val EXTRA_RETRY = "retry"        // 从连接失败返回的标记
        const val EXTRA_FAILED_URL = "failed_url"
    }

    private lateinit var inputLayout: TextInputLayout
    private lateinit var etPort: TextInputEditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val sp = getSharedPreferences("app", MODE_PRIVATE)
        val saved = sp.getInt(KEY_PORT, -1)
        val isRetry = intent.getBooleanExtra(EXTRA_RETRY, false)

        // 已有端口记录且非失败重试 → 直接进入酒馆
        if (!isRetry && saved > 0) {
            enter(saved)
            return
        }

        setContentView(R.layout.activity_setup)
        inputLayout = findViewById(R.id.inputLayout)
        etPort = findViewById(R.id.etPort)
        val btnSave = findViewById<Button>(R.id.btnSave)
        val btnDefault = findViewById<Button>(R.id.btnDefault)

        // hint 只在 TextInputLayout 上浮动显示，避免与 EditText 内 hint 重叠
        // 连不上回来：不弹 toast、不预填，输入框保持空白
        inputLayout.hint = if (saved > 0) "输入端口（上次使用 $saved）" else "输入端口（1-65535）"

        btnSave.setOnClickListener {
            val text = etPort.text?.toString()?.trim().orEmpty()
            if (text.isEmpty()) {
                inputLayout.error = "输入为空：直接用下面的默认端口按钮即可"
                return@setOnClickListener
            }
            val p = text.toIntOrNull()
            if (p == null || p !in 1024..65535) {
                inputLayout.error = "端口需在 1024–65535 之间"
                return@setOnClickListener
            }
            inputLayout.error = null
            saveAndEnter(p)
        }

        btnDefault.setOnClickListener { saveAndEnter(DEFAULT_PORT) }
    }

    private fun enter(port: Int) {
        startActivity(Intent(this, WebActivity::class.java).putExtra(KEY_PORT, port))
        finish()
    }

    private fun saveAndEnter(port: Int) {
        getSharedPreferences("app", MODE_PRIVATE).edit().putInt(KEY_PORT, port).apply()
        enter(port)
    }
}
