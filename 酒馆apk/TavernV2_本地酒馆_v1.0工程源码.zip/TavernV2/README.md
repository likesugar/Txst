# 离线酒馆 v2.1（TavernV2）

**单网页形态（同 v1.5）**：App 启动即把酒馆跑在 `http://127.0.0.1:8000/`，用浏览器打开即用。
Kotlin + Material 3，Android Studio 标准工程，适配 **Android 10 ~ Android 17**（minSdk 29 / targetSdk 36）。

## 使用

1. 安装并打开 App → 服务自动启动（状态点变绿）
2. 点「打开网页」或手动在浏览器输入 `http://127.0.0.1:8000/`
3. 端口被占用时在 App 里改端口并重启
4. API 地址 / Key / 模型在网页版的设置里配置

> gradle-wrapper 已配置腾讯镜像（gradle-8.11.1）。如果 Sync 报网络错误，可把
> `gradle/wrapper/gradle-wrapper.properties` 的 `distributionUrl` 换成任意可达镜像。

## 与 v1.x 的区别

| | v1.x（AIDE 手搓） | v2.0（本工程） |
|---|---|---|
| 界面 | WebView 壳 + 网页 | **Material 3 原生 UI** |
| 构建 | AIDE / aapt2 脚本 | **Android Studio / Gradle** |
| 导入导出 | 申请存储权限 | **SAF 文件选择器，零权限** |
| 数据库 | tavern.db（SQLite） | 同结构，**数据无缝继承** |
| 本地 Web 服务 | 启动即用 | 设置里按需开启（默认关） |

## 功能

- 角色卡管理：名称 / 简介 / 人设 / 开场白（BottomSheet 编辑）
- 会话与消息：流式输出（SSE）、停止、重新生成、长按消息编辑/删除
- LLM 直连：OpenAI 兼容 API（设置里配地址 / Key / 模型）
- 本地 Web 服务（可选）：开启后手机浏览器访问 `http://127.0.0.1:8000` 使用网页版，端口可改
- 数据导入导出 JSON：走系统文件选择器（Android 10+ 标准做法，无需任何权限）

## 目录结构

```
app/src/main/java/com/jiuguan/tavern/
├── App.kt              # 全局单例
├── data/
│   ├── Entities.kt     # Char / Chat / Msg 数据类
│   └── Repository.kt   # SQLite CRUD + 设置存储
├── llm/
│   └── LlmClient.kt    # OpenAI 兼容 API 流式客户端（SSE 解析）
├── server/
│   └── TavernServer.kt # 本地 Web 服务（网页版 + REST API）
└── ui/
    ├── MainActivity.kt     # 角色列表
    ├── ChatActivity.kt     # 聊天（流式）
    ├── SettingsActivity.kt # 设置（API/服务/数据）
    ├── CharEditSheet.kt    # 角色编辑 BottomSheet
    ├── Adapters.kt         # 列表适配器
    └── Markdown.kt         # 轻量 Markdown 渲染
```

## 命令行构建（无 AS 环境）

```bash
./gradlew assembleRelease
# 产物：app/build/outputs/apk/release/app-release-unsigned.apk（需自行签名）
```

## 版本

- v2.0 (versionCode 8)：原生重写 + Material 3 + Android 10–17 适配
- v1.6 及更早：WebView 壳架构（历史版本，数据兼容）
